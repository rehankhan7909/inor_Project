import React, { useEffect } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import Forgotpassword from "./pages/Forgotpassword";
import Login from "./pages/Login";
import OTP from "./pages/OTP";
import Register from "./pages/Register";
import ResetPassword from "./pages/ResetPassword";
import {ToastContainer } from "react-toastify"
import { useDispatch, useSelector } from "react-redux";
import { getUser } from "./store/slices/authSlice";
import { fetchAllusers } from "./store/slices/userSlice";
const App = () => {
  const {user, isAuthenticated} = useSelector((state)=>state.auth);
  const dispatch = useDispatch();
  useEffect(()=>{
    dispatch(getUser());
    if (isAuthenticated && user?.role === "Admin"){
      dispatch(fetchAllusers());
    }
  },[]);
  return(
 <Router>
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/login" element={<Login/>} />
      <Route path="/register" element={<Register/>} />
      <Route path="/password/forgot" element={<Forgotpassword/>} />
      <Route path="/otp-verification/:email" element={<OTP/>} />
      <Route path="/password/reset/:token" element={<ResetPassword/>} />
    </Routes>
    <ToastContainer theme="dark" />
  </Router>
  );

};

export default App;

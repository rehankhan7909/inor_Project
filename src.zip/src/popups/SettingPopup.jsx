import React from 'react'
import closeIcon from "../assets/close-square.png";

const SettingPopup = () => {
  return (
    <div>
      
    </div>
  )
}

export default SettingPopup

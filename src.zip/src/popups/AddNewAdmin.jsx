import React from "react";
import placeHolder from "../assets/placeholder.jpg";
import closeIcon from "../assets/close-square.png";
import keyIcon from "../assets/key.png";

const AddNewAdmin = () => {
  return <>
  <h1> Add NEw Admin 
  </h1>
  </>;
};

export default AddNewAdmin;

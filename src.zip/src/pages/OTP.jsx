import React from "react";
import logo from "../assets/black-logo.png";
import logo_with_title from "../assets/logo-with-title.png";
import { useState } from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import { useDispatch } from "react-redux";
import {otpVerification, resetAuthSlice} from "../store/slices/authSlice";
import { toast } from "react-toastify";
import { useEffect} from "react";
import { useSelector } from "react-redux";


const OTP = () => {
const {email} = useParams();
const [otp, setOtp] =useState("");
const dispatch = useDispatch();


const {loading,error, message,isAuthenticated
} = useSelector((state)=> state.auth);

const handleOtpVerification = (e) => {
  e.preventDefault();
  dispatch(verifyOTP(email, otp));
};

useEffect(() => {
  if(message) {
   toast.success(message);
  }
  if(error) {
     toast.error(error);
     dispatch(resetAuthSlice());
   }
},[dispatch,isAuthenticated,error,loading]);

if (isAuthenticated) {
return <Navigate to={"/"} />
}
return (
  <div className="flex flex-col md:flex-row h-screen overflow-hidden">
    {/* LEFT SIDE */}
    <div className="w-full md:w-1/2 flex flex-col justify-center items-center bg-white p-8 relative">
      <Link
        to="/login"
        className="border-2 border-black rounded-full font-bold w-24 py-2 px-4 absolute top-10 left-10
                   hover:bg-black hover:text-white transition duration-300 text-center"
      >
        Back
      </Link>

      <div className="max-w-sm w-full">
        <div className="flex justify-center mb-8">
          <div className="rounded-full flex items-center justify-center">
            <img src={logo} alt="logo" className="h-24 w-auto" />
          </div>
        </div>

        <h1 className="text-4xl font-medium text-center mb-4">
          Check your Mailbox
        </h1>

        <p className="text-gray-600 text-center mb-8">
          Please enter the otp to proceed
        </p>

        <form onSubmit={handleOtpVerification}>
          <div className="mb-4">
            <input
              type="number"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              placeholder="OTP"
              className="w-full px-4 py-3 border border-black rounded-md focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="border-2 mt-4 border-black w-full font-semibold bg-black text-white py-2 rounded 
                       hover:bg-white hover:text-black transition"
          >
            VERIFY
          </button>
        </form>
      </div>
    </div>

    {/* RIGHT SIDE */}
    <div className="hidden md:flex w-full md:w-1/2 bg-black text-white flex-col items-center justify-center p-8 rounded-tl-[80px] rounded-bl-[80px] overflow-hidden">
      <div className="text-center">
        <div className="flex justify-center mb-8">
          <img src={logo_with_title} alt="logo" className="h-44 w-auto" />
        </div>

        <p className="text-gray-300 mb-8">
          New to our platform? Sign up now.
        </p>

        <Link
          to="/register"
          className="border-2 border-white px-8 font-semibold bg-black text-white py-2 rounded-lg 
                     hover:bg-white hover:text-black transition"
        >
          SIGN UP
        </Link>
      </div>
    </div>
  </div>
);


 

};

export default OTP;



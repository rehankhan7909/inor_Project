import React from "react";
import { useState } from "react";
import logo from "../assets/black-logo.png";
import logo_with_title from "../assets/logo-with-title.png";
import { useDispatch, useSelector } from "react-redux";
import { login, resetAuthSlice } from "../store/slices/authSlice";
import { toast } from "react-toastify";
import { Navigate } from "react-router-dom";
import { useEffect} from "react";
const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const dispatch = useDispatch();
  
  const {loading,error, message,isAuthenticated
  } = useSelector(state=> state.auth);

  const handleLogin = (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append("email", email);
    data.append("password", password);
    dispatch(login(data));

    useEffect(() => {
      if(message) {
       toast.success(message);
       dispatch(resetAuthSlice());
      }
      if(error) {
         toast.error(error);
         dispatch(resetAuthSlice());
       }
    },[dispatch,isAuthenticated,error,loading]);
   
   if (isAuthenticated) {
    return <Navigate to={"/"} />
   }
   
  }
  return <>
   
  <div className="min-h-screen flex items-center justify-center bg-black p-4 ">
       <div className="flex  justify-center items-center mb-14 text-black">
             <img src={logo_with_title} alt="logo"className="mb-12 h-42 w-auto px-10" />
            </div>
    <div className="w-full max-w-md bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-3xl font-bold text-center mb-6">Login</h2>
      <form className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1 ">
            Email
          </label>
          <input
            type="email"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-black"
            placeholder="you@example.com"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <input
            type="password"
            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-black"
            placeholder="Enter your password"
          />
        </div>
        <div className="text-right text-sm">
          <a href="/password/forgot" className="text-black hover:underline">
            Forgot Password?
          </a>
        </div>
        <button
          type="submit"
          className="w-full bg-black text-white py-3 rounded-xl font-semibold hover:bg-gray-900 transition"
        >
          Login
        </button>
      </form>
      <p className="mt-6 text-sm text-center text-gray-600">
        Don’t have an account?{" "}
        <a href="/register" className="text-black font-medium hover:underline">
          Register
        </a>
      </p>
    </div>
  </div>

  </>;
};

export default Login;

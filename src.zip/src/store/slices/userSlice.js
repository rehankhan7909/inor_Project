import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { toast } from "react-toastify";
import AddNewAdmin from "../../popups/AddNewAdmin";

const userSlice = createSlice({
        name : "user",
        initialState: {
            loading: false,
            user: [],
           
        },
        reducers: {
            fetchAlluserRequest: (state) => {
           state.loading = true;
        },
        fetchAlluserSuccess: (state) => {
            state.loading = false;
            state.user = action.payload;
         },
         fetchAlluserFailed: (state) => {
            state.loading = false;
    
         },
         addNewAdminRequest(state){
            state.loading = true;
         },
         addNewAdminSuccess(state){
            state.loading = false;

         },
         addNewAdminFailed(state){
            state.loading = false;
         },
},
})

export const fetchAllusers = () => async (dispatch) => {
    dispatch(authSlice.actions.fetchAllusersRequest());
    await axios
    .post("http://localhost:4000/api/v1/auth/user/all",{
        withCredentials: true,
        
    }).then((res) => {
        dispatch(authSlice.actions.fetchAllusersSuccess(res.data.users));
    }).catch((err) => {
        dispatch(authSlice.actions.fetchAllusersFail(err.response.data.message));
    });
}

export const addNewAdmin = (data) => async (dispatch) => {
    dispatch(authSlice.actions.addNewAdminRequest())
    await axios
    .post("http://localhost:4000/api/v1/auth/user/add/new-admin",data,{
        withCredentials: true,
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    }).then((res) => {
        dispatch(authSlice.actions.addNewAdminSuccess());
        toast.success(res.data.message)

    }).catch((err) => {
        dispatch(authSlice.actions.addNewAdminFailed());
        toast.error(err.response.data.message)
    });
};

export default userSlice.reducer;
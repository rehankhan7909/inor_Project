import { createSlice, ReducerType } from '@reduxjs/toolkit'

const popUpSlice= createSlice({
    name: 'popup',
    initialState: {
        settingPopup: false,
        addBookPopup: false,
        readBookPopup: false,
        recordbookPopup: false,
        returnBookPopup: false,
        addNewAdminPopup: false,     
},
reducers:{
    toggleSettingPopup: (state) => {
        state.settingPopup = !state.settingPopup
    },
    toggleAddBookPopup: (state) => {
        state.addBookPopup = !state.addBookPopup
    },
    toggleReadBookPopup: (state) => {
        state.readBookPopup = !state.readBookPopup
    },
    toggleRecordBookPopup: (state) => {
        state.recordbookPopup = !state.recordbookPopup
    },
    toggleReturnBookPopup: (state) => {
        state.returnBookPopup = !state.returnBookPopup
    },
    toggleAddNewAdminPopup: (state) => {
        state.addNewAdminPopup = !state.addNewAdminPopup
    },
    closeAllPopups: (state) => {
        state.settingPopup = false
        state.addBookPopup = false
        state.readBookPopup = false
        state.recordbookPopup = false
        state.addNewAdminPopup = false
        state.returnBookPopup = false
    },
},
});

export const {
closeAllPopups,
toggleAddBookPopup,
toggleReadBookPopup,
toggleRecordBookPopup,
toggleReturnBookPopup,
toggleAddNewAdminPopup,
toggleSettingPopup,
} = popUpSlice.actions;

export default popUpSlice.reducer;
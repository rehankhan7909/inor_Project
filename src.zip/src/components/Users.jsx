import React from "react";
import { useSelector } from "react-redux";
import Header from "../layout/Header"

const Users = () => {
  const {user} = useSelector((state)=> state.user);
  
  const formatDate= (timeStamp)=>{
const date = new Date(timeStamp);
  const formattedDate= `${string(date.getDate()).padStart(2,"0")}-${String(
  date.getMonth()+1
).padStart(2,"0")}-${String(date.getFullYear()) }`;

const formattedTime= `${string(date.getHours()).padStart(2,"0")}-${String(
  date.getMinutes()
).padStart(2,"0")}:${String(date.getSeconds()).padStart(2,"0") }`;
const result  = `${formattedDate} ${formattedTime}`;
 return result;

}

  return <>
  <main className="relative flex-1 p-6 pt-28 ">
   <Header/>
  </main>
  </>;
};

export default Users;

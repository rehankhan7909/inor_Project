import React from "react";
import { PiKeyReturnBold } from "react-icons/pi";
import { FaSquareCheck } from "react-icons/fa6";

const Catalog = () => {
  return <></>;
};

export default Catalog;

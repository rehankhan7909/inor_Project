import React from "react";
import { BookA, NotebookPen } from "lucide-react";

const BookManagement = () => {
  return <></>;
};

export default BookManagement;
